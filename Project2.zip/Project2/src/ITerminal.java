public interface ITerminal {
     void Truckin(Truck S);// meant to add incoming trucks to the arraylist
    void Truckout(Truck S);// meant to delete trucks that are leaving the terminal



    }


