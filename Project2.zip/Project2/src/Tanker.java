public class Tanker extends Heavy{
    double weightperUnit;
    double Tanker;
    double fuelConsumption=4.00/weightperUnit;

    Tanker(int ID, double weight) {
        super(ID, weight);
    }
}
